// card.tsx - placeholder content
